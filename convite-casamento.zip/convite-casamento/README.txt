PROJETO PRONTO - CONVITE DIGITAL DE CASAMENTO

ESTRUTURA:
- frontend/index.html
- frontend/style.css
- frontend/script.js
- backend-java/ (Spring Boot)

COMO ABRIR O FRONTEND:
1. Abra a pasta frontend no VS Code.
2. Abra o arquivo index.html no navegador.

COMO RODAR O BACKEND JAVA:
1. Abra a pasta backend-java no terminal.
2. Execute: mvn spring-boot:run
3. O servidor iniciará em: http://localhost:8080

ROTAS:
- POST http://localhost:8080/confirmar
- GET  http://localhost:8080/confirmacoes

OBSERVAÇÃO:
O frontend envia a confirmação de presença para o backend Java.
O anfitrião pode visualizar todas as confirmações acessando /confirmacoes.
