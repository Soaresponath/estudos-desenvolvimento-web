const form = document.getElementById("rsvpForm");
const statusElement = document.getElementById("status");
const submitBtn = document.getElementById("submitBtn");

const API_URL = "http://localhost:8080/confirmar";

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const dados = {
    nome: document.getElementById("nome").value.trim(),
    presenca: document.getElementById("presenca").value,
    acompanhantes: Number(document.getElementById("acompanhantes").value || 0),
    telefone: document.getElementById("telefone").value.trim(),
    mensagem: document.getElementById("mensagem").value.trim()
  };

  if (!dados.nome || !dados.presenca) {
    mostrarStatus("Preencha os campos obrigatórios.", "error");
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "Enviando...";
  mostrarStatus("", "");

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(dados)
    });

    const resultado = await response.text();

    if (!response.ok) {
      throw new Error(resultado || "Erro ao enviar confirmação.");
    }

    mostrarStatus("Confirmação enviada com sucesso!", "success");
    form.reset();
    document.getElementById("acompanhantes").value = 0;
  } catch (error) {
    mostrarStatus("Não foi possível conectar ao servidor Java. Verifique se ele está rodando.", "error");
    console.error(error);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Confirmar presença";
  }
});

function mostrarStatus(mensagem, tipo) {
  statusElement.textContent = mensagem;
  statusElement.className = `status ${tipo}`.trim();
}
