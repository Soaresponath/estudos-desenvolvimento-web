package com.convite.casamento.controller;

import com.convite.casamento.model.Confirmacao;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping
@CrossOrigin(origins = "*")
public class ConfirmacaoController {

    private final List<Confirmacao> confirmacoes = new ArrayList<>();

    @PostMapping("/confirmar")
    public ResponseEntity<String> confirmar(@RequestBody Confirmacao confirmacao) {
        if (confirmacao.getNome() == null || confirmacao.getNome().isBlank()) {
            return ResponseEntity.badRequest().body("O nome do convidado é obrigatório.");
        }

        if (confirmacao.getPresenca() == null || confirmacao.getPresenca().isBlank()) {
            return ResponseEntity.badRequest().body("A informação de presença é obrigatória.");
        }

        confirmacoes.add(confirmacao);

        System.out.println("========================================");
        System.out.println("Nova confirmação recebida");
        System.out.println("Nome: " + confirmacao.getNome());
        System.out.println("Presença: " + confirmacao.getPresenca());
        System.out.println("Acompanhantes: " + confirmacao.getAcompanhantes());
        System.out.println("Telefone: " + confirmacao.getTelefone());
        System.out.println("Mensagem: " + confirmacao.getMensagem());
        System.out.println("========================================");

        return ResponseEntity.ok("Confirmação recebida com sucesso!");
    }

    @GetMapping("/confirmacoes")
    public ResponseEntity<List<Confirmacao>> listarConfirmacoes() {
        return ResponseEntity.ok(confirmacoes);
    }
}
