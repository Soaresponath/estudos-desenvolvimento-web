package com.convite.casamento.model;

public class Confirmacao {

    private String nome;
    private String presenca;
    private int acompanhantes;
    private String telefone;
    private String mensagem;

    public Confirmacao() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPresenca() {
        return presenca;
    }

    public void setPresenca(String presenca) {
        this.presenca = presenca;
    }

    public int getAcompanhantes() {
        return acompanhantes;
    }

    public void setAcompanhantes(int acompanhantes) {
        this.acompanhantes = acompanhantes;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}
